import bump_img01 from '../assets/images/contact-thankyou/bump_img01.png';
import bump_img02 from '../assets/images/bump_img02.png';
import bump_img03 from '../assets/images/bump_img03.png';
import bump_img04 from '../assets/images/bump_img04.png';
import bump_img05 from '../assets/images/bump_img05.png';
import bump_img06 from '../assets/images/bump_img06.png';
import bump_img07 from '../assets/images/bump_img07.png';
import bump_img08 from '../assets/images/bump_img08.png';
import bump_img09 from '../assets/images/bump_img09.png';
import cake_img02 from '../assets/images/contact-thankyou/cake_img02.png';
import bump_img10 from '../assets/images/bump_img10.png';
import bump_img11 from '../assets/images/bump_img11.png';
import cake_img01 from '../assets/images/cake_img01.png';
import family_img01 from '../assets/images/contact-thankyou/family_img01.png';
import family_img02 from '../assets/images/contact-thankyou/family_img02.png';
import family_img03 from '../assets/images/family_img03.png';
import family_img04 from '../assets/images/family_img04.png';
import family_img05 from '../assets/images/family_img05.png';
import family_img06 from '../assets/images/family_img06.png';
import family_img07 from '../assets/images/family_img07.png';
import family_img08 from '../assets/images/family_img08.png';
import family_img09 from '../assets/images/family_img09.png';
import family_img10 from '../assets/images/family_img10.png';
import family_img11 from '../assets/images/family_img11.png';
import family_img12 from '../assets/images/family_img12.png';
import family_img13 from '../assets/images/contact-thankyou/family_img13.png';
import family_img14 from '../assets/images/family_img14.png';
import home_left_nav_svg from '../assets/images/home_left_nav_svg.svg';
import home_right_nav_svg from '../assets/images/home_right_nav_svg.svg';
import myimg from '../assets/images/myimg.png';
import kids_img01 from '../assets/images/kids_img01.png';
import kids_img02 from '../assets/images/kids_img02.png';
import kids_img03 from '../assets/images/contact-thankyou/kids_img03.png';
import kids_img04 from '../assets/images/kids_img04.png';
import kids_img05 from '../assets/images/kids_img05.png';
import kids_img06 from '../assets/images/kids_img06.png';
import kids_img07 from '../assets/images/kids_img07.png';
import kids_img08 from '../assets/images/kids_img08.png';
import kids_img09 from '../assets/images/kids_img09.png';
import kids_img10 from '../assets/images/kids_img10.png';
import kids_img11 from '../assets/images/kids_img11.png';
import kids_img12 from '../assets/images/kids_img12.png';
import kids_img13 from '../assets/images/kids_img13.png';
import kids_img14 from '../assets/images/kids_img14.png';
import kids_img15 from '../assets/images/kids_img15.png';
import kids_img16 from '../assets/images/kids_img16.png';
import kids_img17 from '../assets/images/kids_img17.png';
import kids_img18 from '../assets/images/kids_img18.png';
import kids_img19 from '../assets/images/kids_img19.png';
import kids_img20 from '../assets/images/kids_img20.png';
import kids_img21 from '../assets/images/kids_img21.png';
import kids_img22 from '../assets/images/kids_img22.png';
import kids_img23 from '../assets/images/kids_img23.png';
import newborn_img06 from '../assets/images/contact-thankyou/newborn_img06.png';
import newborn_img07 from '../assets/images/newborn_img07.png';
import newborn_img08 from '../assets/images/newborn_img08.png';
import newborn_img09 from '../assets/images/newborn_img09.png';
import newborn_img10 from '../assets/images/newborn_img10.png';
import newborn_img11 from '../assets/images/newborn_img11.png';
import newborn_img12 from '../assets/images/newborn_img12.png';
import newborn_img13 from '../assets/images/newborn_img13.png';
import portfolio_left_nav_svg from '../assets/images/portfolio_left_nav_svg.svg';
import portfolio_right_nav_svg from '../assets/images/portfolio_right_nav_svg.svg';
import sjw_logo from '../assets/images/sjw_logo.svg';
import sj_logo_cropped from '../assets/images/sj_logo_cropped.svg';
import sj_logo from '../assets/images/sj_logo.svg';
import sj_logo01 from '../assets/images/sj_logo01.svg';
import sj_logo02 from '../assets/images/sj_logo02.svg';
import child_icon from '../assets/images/child_icon.svg';



export default {
  bump_img01,
  bump_img02,
  bump_img03,
  bump_img04,
  bump_img05,
  bump_img06,
  bump_img07,
  bump_img08,
  bump_img09,
  bump_img10,
  bump_img11,
  cake_img01,
  cake_img02,
  family_img01,
  family_img02,
  family_img03,
  family_img04,
  family_img05,
  family_img06,
  family_img07,
  family_img08,
  family_img09,
  family_img10,
  family_img11,
  family_img12,
  family_img13,
  family_img14,
  home_left_nav_svg,
  home_right_nav_svg,
  myimg,
  kids_img01,
  kids_img02,
  kids_img03,
  kids_img04,
  kids_img05,
  kids_img06,
  kids_img07,
  kids_img08,
  kids_img09,
  kids_img10,
  kids_img11,
  kids_img12,
  kids_img13,
  kids_img14,
  kids_img15,
  kids_img16,
  kids_img17,
  kids_img18,
  kids_img19,
  kids_img20,
  kids_img21,
  kids_img22,
  kids_img23,
  newborn_img06,
  newborn_img07,
  newborn_img08,
  newborn_img09,
  newborn_img10,
  newborn_img11,
  newborn_img12,
  newborn_img13,
  portfolio_left_nav_svg,
  portfolio_right_nav_svg,
  sjw_logo,
  sj_logo_cropped,
  sj_logo,
  sj_logo01,
  sj_logo02,
  child_icon
};