import Home from './Home/Home';
import Portfolio from './Portfolio/Portfolio';
import WhoIam from './WhoIam/WhoIam';
import Testimonials from './Testimonials/Testimonials';
import Contact from './Contact/Contact';
import Footer from './Footer/Footer';
export Socialicons from './Socialicons/Socialicons';

export {
  Home,
  Portfolio,
  WhoIam,
  Contact,
  Testimonials,
  Footer,
  Socialicons
};
